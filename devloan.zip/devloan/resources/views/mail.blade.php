<h1>Hi, {{ $name }}</h1>
<p>Your loan applicaiton has been approved, Please find the attachement and details.</p>
<p>Thank you</p>